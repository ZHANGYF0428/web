package com.miaodiyun.huiDiao.entity;

public class ReceNoticeResp
{
	private String respCode;

	public String getRespCode()
	{
		return respCode;
	}

	public void setRespCode(String respCode)
	{
		this.respCode = respCode;
	}
}
