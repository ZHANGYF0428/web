package com.lanou.web;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class YanZhengCode
 */
@WebServlet("/yan.do")
public class YanZhengCode extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static int WIDTH=100;
	private final static int HEIGTH=30;
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//创建画板
		BufferedImage image = new BufferedImage(WIDTH, HEIGTH, BufferedImage.TYPE_3BYTE_BGR);
		//让画布每一个颜色块显示不一样的颜色
		for (int i = 0; i < WIDTH; i++) {
			for (int j = 0; j < HEIGTH; j++) {
				int color = (int)(Math.random()*0xFFFFFF);
				image.setRGB(i, j, color);					
			}
		}
		
		//创建画笔
		Graphics g = image.getGraphics();
		Random random = new Random();
		g.setColor(new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
		//设置字体大小和样式
		g.setFont(new Font(Font.SANS_SERIF, Font.BOLD,30));
		
		//随机生成一个验证码
		String code = GetCode();
		
		g.drawString(code,30 , 30);
		
		//画五条干扰线
		for (int i = 0; i < 5; i++) {
			int x1 = random.nextInt(100);
			int x2 = random.nextInt(30);
			int y1 = random.nextInt(100);
			int y2 = random.nextInt(30);
			g.drawLine(x1, y1, x2, y2);
		}
		
		
		//设置内容格式
		response.setContentType("image/png");
		
		//通过输出流将图片输出
		OutputStream out= response.getOutputStream();
		ImageIO.write(image, "png", out);
		out.close();
		HttpSession session = request.getSession();
		session.setAttribute("code",code);
	}
	//生成四位验证码
	public static String GetCode(){
		
		//所有字符
		String codes="";
		for (int i = 0; i <= 9; i++) {
			codes+=i;
		}
		for (char c1 = 'a';c1<='z'; c1++) {
			codes+=c1;
		}
		for (char c1 = 'A';c1<='Z'; c1++) {
			codes+=c1;
		}
		//从codes中随机取出4个字符
		String code = "";
		for(int i=0;i<4;i++)
		{//随机获取一个下标
			int index = new Random().nextInt(codes.length());
			code+=codes.charAt(index);
			
		}
		
		return code;
		
	}
	public static void main(String[] args) {
		System.out.println(GetCode());;
	}

}
