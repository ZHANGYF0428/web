package com.lanou.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
/**
 * 过滤器组件对象
 * 对评论的内容进行过滤
 * @author xalo
 *
 */
@WebFilter("/comment.do")
public class CommentFilter implements Filter{

	@Override
	public void destroy() {
		System.out.println("filter-destroy");
	}
	/**
	 * 执行过滤的代码
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)throws IOException, ServletException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		System.out.println("filter-dafilter");//放过请求，让他继续执行后续逻辑，到Servlet
		String content = request.getParameter("comment");
		if (content.contains("共产党")) {
			out.println("内容包含违禁词");
		}else {			
			chain.doFilter(request, response);
		}
		out.close();
	}
	/*
	 * filter过滤器初始化方法
	 * 容器启动时初始化
	 * 
	 */
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("filter-init");
	}

}
