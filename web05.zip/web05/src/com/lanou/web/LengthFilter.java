package com.lanou.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * 针对评论内容的长度进行过滤
 * @author xalo
 *
 */
@WebFilter("/comment.do")
public class LengthFilter implements Filter{

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		//获取评论信息
		String comment = request.getParameter("comment");
		//判断内容的长度
		if (comment.length()>10) {
			out.println("评论的内容过长");
		}else if (comment.length()==0) {
			out.println("无评论内容");			
		}else {
			chain.doFilter(request, response);
		}
	
	
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		// TODO Auto-generated method stub
	String keyWord = config.getInitParameter("keyWord");
	System.out.println("keyWord="+keyWord);
	
	}

}
