package com.lanou.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lanou.bean.Emp;
import com.lanou.dao.EmpDao;
import com.lanou.dao.UserDao;
import com.lanou.util.DaoFactory;
import com.lanou.util.GlobalConst;
import com.lanou.util.JdbcUtil;
public class ActionServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		//uri=/web05/listEmp.do
		//    /web05/addEmp.do
		//    /web05/deleteEmp.do
		String uri = request.getRequestURI();
		uri = uri.substring(uri.lastIndexOf("/")+1,uri.length());
		
		HttpSession session = request.getSession();
		session.setMaxInactiveInterval(10);
		
		
		
		
		if("listEmp.do".equals(uri)){
			//Session验证，判断用户有没有登录
			String username =(String)session.getAttribute("username");
			if (username==null) {
				//没登录过
				//重定向到登录页面
				response.sendRedirect("login.jsp");
				return;
			}
			
			
			EmpDao dao = DaoFactory.getEmpDao(GlobalConst.JDBC);
			List<Emp> emps = dao.findAll();
			request.setAttribute("emps",emps);
			request.getRequestDispatcher("empList.jsp").forward(request, response);	
			out.close();
		}else if("delEmp.do".equals(uri)){
			//Session验证，判断用户有没有登录
			String username =(String)session.getAttribute("username");
			if (username==null) {
				//没登录过
				//重定向到登录页面
				response.sendRedirect("login.jsp");
				return;
			}
			int id = Integer.parseInt(request.getParameter("id"));
			EmpDao dao = DaoFactory.getEmpDao(GlobalConst.JDBC);
			dao.deleteEmpById(id);
			response.sendRedirect("listEmp.do");
		}else if("toUpdate.do".equals(uri)){
			//Session验证，判断用户有没有登录
			String username =(String)session.getAttribute("username");
			if (username==null) {
				//没登录过
				//重定向到登录页面
				response.sendRedirect("login.jsp");
				return;
			}
			int id = Integer.parseInt(request.getParameter("id"));
			EmpDao dao = DaoFactory.getEmpDao(GlobalConst.JDBC);
			Emp emp = dao.findEmpById(id);
			//将获取到的数据emp转发到updateEmp.jsp
			request.setAttribute("emp",emp);
			request.getRequestDispatcher("updateEmp.jsp").forward(request,response);
			
		}else if("addEmp.do".equals(uri)){
			//Session验证，判断用户有没有登录
			String username =(String)session.getAttribute("username");
			if (username==null) {
				//没登录过
				//重定向到登录页面
				response.sendRedirect("login.jsp");
				return;
			}
			String name = request.getParameter("name");
			double salary = Double.parseDouble(request.getParameter("salary"));
			int age = Integer.parseInt(request.getParameter("age"));
			Emp emp = new Emp();
			emp.setName(name);
			emp.setSalary(salary);
			emp.setAge(age);
		EmpDao dao = DaoFactory.getEmpDao(GlobalConst.JDBC);
			dao.save(emp);
			response.sendRedirect("listEmp.do");
		}else if("updateEmp.do".equals(uri)){
			//Session验证，判断用户有没有登录
			String username =(String)session.getAttribute("username");
			if (username==null) {
				//没登录过
				//重定向到登录页面
				response.sendRedirect("login.jsp");
				return;
			}
			int id = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			double salary = Double.parseDouble(request.getParameter("salary"));
			int age = Integer.parseInt(request.getParameter("age"));
			Emp emp = new Emp(id, name, salary, age);	
			EmpDao dao = DaoFactory.getEmpDao(GlobalConst.JDBC);
			dao.update(emp);
			response.sendRedirect("listEmp.do");
		}else if ("login.do".equals(uri)) {
			//获取用户表单提交的账号密码
			String code = request.getParameter("code");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String acode =  (String)session.getAttribute("code");
		
				if (!acode.equalsIgnoreCase(code)) {
					//验证码输入错误
					//往Session对象中存入一个错误信息
					session.setAttribute("er","验证码输入错误！");						
					//登录不成功，重定向到登录页面
					response.sendRedirect("login.jsp");
					return;
				}
			
			//调用dao中的方法，判断账号密码是否在数据库中
			UserDao dao = DaoFactory.getUserDao();
			boolean isExists =  dao.findUserByNameAndPwd(username, password);
			if (isExists) {
				//存在，登录成功
				//登录成功，存入用户姓名
				session.setAttribute("username",username);
				response.sendRedirect("listEmp.do");
			}else{
				//往Session对象中存入一个错误信息
				session.setAttribute("er","账号或密码错误!");
								
				//登录不成功，重定向到登录页面
				response.sendRedirect("login.jsp");
			}
		}else if ("logout.do".equals(uri)){
			//销毁Session
			session.invalidate();
			//重定向到登录页面
			response.sendRedirect("login.jsp");
		}else if ("comment.do".equals(uri)) {
			//设置编码
			request.setCharacterEncoding("utf-8");
			response.setContentType("text/html;charset=utf-8");
			//获取用户的评论信息
			String comment = request.getParameter("comment");
			out.println(comment);
			out.close();
			
		}
		else if ("addpeo.do".equals(uri)) {
			String name = request.getParameter("username");
			String password = request.getParameter("password");
			String replacepassword = request.getParameter("replacepassword");
			Connection connection = JdbcUtil.getConnection();
			String sql="select * from user where username=?";
			try {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, name);
			ResultSet set = preparedStatement.executeQuery();
			if (set.next()) {
				//往Session对象中存入一个错误信息
				session.setAttribute("er","账号存在");
				//登录不成功，重定向到登录页面
				response.sendRedirect("login.jsp");
			}else if (!(password.equals(replacepassword))) {
				//往Session对象中存入一个错误信息
				session.setAttribute("er","两次密码不一致");
				//密码不一致，重定向到登录页面
				response.sendRedirect("login.jsp");
			}else if (password.length()<8||replacepassword.length()<8) {
				//往Session对象中存入一个错误信息
				session.setAttribute("er","密码不能小于八位");
				//密码小于八位，重定向到登录页面
				response.sendRedirect("login.jsp");
			}else if (password.length()>16||replacepassword.length()>16) {
				//往Session对象中存入一个错误信息
				session.setAttribute("er","密码不能大于十六位");
				//密码大于16位，重定向到登录页面
				response.sendRedirect("login.jsp");
			}else {
				sql="insert into user(username,password) values(?,?)";
				PreparedStatement prt =  connection.prepareStatement(sql);
				prt.setString(1, name);
				prt.setString(2, password);
				prt.executeUpdate();
				//往Session对象中存入一个注册成功对象
				session.setAttribute("er","注册成功！请登录");					
				//注册成功，重定向到登录页面
				response.sendRedirect("login.jsp");
			}			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
		}
		
		
	}
}
