package com.lanou.util;
import com.lanou.dao.EmpDao;
import com.lanou.dao.EmpDaoImpl;
import com.lanou.dao.UserDao;
import com.lanou.dao.UserDaoImpl;

/**
 * �������ģʽ
 */
public class DaoFactory {
	/**
	 * ר�����ڴ���EmpDaoʵ����ķ���
	 */
	public static UserDao getUserDao(){
		return  new UserDaoImpl();
	}

	public static EmpDao getEmpDao(int jdbc) {
		// TODO Auto-generated method stub
		return new EmpDaoImpl();
	}
}






