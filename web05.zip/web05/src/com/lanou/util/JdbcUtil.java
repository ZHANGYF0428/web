package com.lanou.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.eclipse.jdt.internal.compiler.batch.Main;
/**
 * Jdbc������ع��߰�
 */
public class JdbcUtil {

	public static Properties load(){
		Properties pro = new Properties();
		InputStream in = JdbcUtil.class
				.getClassLoader()
				.getResourceAsStream("jdbc.properties");
		try {
			pro.load(in);
		} catch (IOException e) {
			e.printStackTrace();}
		return pro;
	}
	public static Connection getConnection(){
		Properties pro = load();
		try {
			Class.forName(pro.getProperty("driver"));
			Connection conn = DriverManager.getConnection(
					pro.getProperty("url"), 
					pro.getProperty("username"), 
					pro.getProperty("password"));
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
}






