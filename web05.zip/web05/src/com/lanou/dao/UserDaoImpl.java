package com.lanou.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.lanou.util.JdbcUtil;

public class UserDaoImpl implements UserDao{

	@Override
	public boolean findUserByNameAndPwd(String name, String password) {
		// TODO Auto-generated method stub
		//连接数据库根据账号密码执行查询
		Connection conn = JdbcUtil.getConnection();
		//预编译sql语句
		String sql = "select * from user where username=? and password=?";
		try {
			PreparedStatement preparedStatement =  conn.prepareStatement(sql);
			preparedStatement.setString(1,name);
			preparedStatement.setString(2, password);
		ResultSet set = preparedStatement.executeQuery();
		if (set.next()) {
			return true;
		}else {
			return false;
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

}
