package com.lanou.dao;
/*与用户表相关的操作
 * */
public interface UserDao {
/**
 * 根据账号和密码查询记录
 * @param username 用户在页面上填写的账号
 * @param password 用户在页面上填写的密码
 * @return return 根据用户填写的账号密码查找到的记录
 * */
	public boolean findUserByNameAndPwd(String name,String password);
	
	
}
