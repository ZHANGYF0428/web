package com.lanou.dao;

import java.util.List;

import com.lanou.bean.Emp;

public class MyBatisImpl implements EmpDao{

	@Override
	public List<Emp> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteEmpById(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void save(Emp emp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Emp emp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Emp findEmpById(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
